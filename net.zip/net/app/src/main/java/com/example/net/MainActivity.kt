package com.example.net

import android.os.Bundle

import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape

import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button

import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight

import androidx.compose.ui.text.style.TextDecoration

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

import com.example.net.viewmodel.PostViewModel
import com.example.net.viewmodel.PostViewModelFactory
import com.example.net.data.DataRep
import com.example.net.model.Post
import com.example.net.ui.theme.NetTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NetTheme {
                // A surface container using the 'background' color from the theme
                Surface(color = MaterialTheme.colorScheme.background) {
                    val postViewModel: PostViewModel = viewModel(
                        factory = PostViewModelFactory(DataRep())
                    )
                    val posts by postViewModel.posts.collectAsState()
                    val selectedPost by postViewModel.selectedPost.collectAsState()
                    val isEditing by postViewModel.isEditing.collectAsState()
                    Post1(
                        p = posts,
                        selecteP = selectedPost,
                        edit = isEditing,
                        onClick1 = { postViewModel.selectPost(it) },
                        onClick2 = { postViewModel.toggleEditing() },
                        title = { postViewModel.updateTitle(it) },
                        change = { postViewModel.updateBody(it) },
                        saveClick = { postViewModel.savePost() }
                    )
                }
            }
        }
    }
}


@Composable
fun Post1(
    p: List<Post>,
    selecteP: Post?,
    edit: Boolean,
    onClick1: (Post) -> Unit,
    onClick2: () -> Unit,
    title: (String) -> Unit,
    change: (String) -> Unit,
    saveClick: () -> Unit
) {
    Row(Modifier.fillMaxSize()) {
        Post2(
            p = p,
            selectP = selecteP,
            onClick = onClick1
        )
        Post4(
            p = selecteP,
            edit = edit,
            onEdit = onClick2,
            onTitle = title,
            body = change,
            save = saveClick
        )
    }
}

@Composable
fun Post2(
    p: List<Post>,
    selectP: Post?,
    onClick: (Post) -> Unit
) {
    Column(
        modifier = Modifier
            .width(220.dp)
            .fillMaxHeight()
            .padding(9.dp)
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = stringResource(R.string.posts_list),
            fontWeight = FontWeight.Bold,
            fontFamily= FontFamily.Serif,
            color = Color.Blue,
            fontStyle = FontStyle.Italic,
            letterSpacing = 2.sp,
            fontSize=20.sp,
            textDecoration = TextDecoration.Underline
        )
        p.forEach { post ->
            Post3(
                p = post,
                isSelect = post == selectP,
                onClick = { onClick(post) }
            )
        }
    }
}

@Composable
fun Post3(
    p: Post,
    isSelect: Boolean,
    onClick: () -> Unit
) {
    if(isSelect){
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick),
            colors = CardDefaults.cardColors(Color(0xFFEB7D7D)),
            shape = CircleShape,
        )
        {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = p.title,
                    fontFamily= FontFamily.Serif,
                    color = Color.Blue,
                    fontStyle = FontStyle.Italic,
                    maxLines = 1,
                    fontSize=20.sp
                )
                Text(
                    text = "Post №${p.id}",
                    fontFamily= FontFamily.Serif,
                    color = Color.Blue,
                    fontStyle = FontStyle.Italic,
                    fontSize=18.sp

                )
            }
        }
    }
    else{
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick),
            colors = CardDefaults.cardColors(Color(0xFFD1AEAE)),

            shape = CircleShape,
        )
        {
            Column(
                modifier = Modifier.padding(15.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Пост №${p.id}",
                    fontWeight = FontWeight.Bold,
                    fontFamily= FontFamily.Serif,
                    color = Color.Blue,
                    fontStyle = FontStyle.Italic,
                    textDecoration = TextDecoration.Underline,
                    fontSize=18.sp

                )
                Text(
                    text = p.title,
                    fontFamily= FontFamily.Serif,
                    color = Color.Blue,
                    fontStyle = FontStyle.Italic,
                    textDecoration = TextDecoration.Underline,
                    maxLines = 1,
                    fontSize=18.sp
                )

            }
        }
    }

}

@Composable
fun Post4(
    p: Post?,
    edit: Boolean,
    onEdit: () -> Unit,
    onTitle: (String) -> Unit,
    body: (String) -> Unit,
    save: () -> Unit
) {
    Column(
        modifier = Modifier
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.post),
            fontWeight = FontWeight.Bold,
            fontFamily= FontFamily.Serif,
            color = Color.Blue,
            fontStyle = FontStyle.Italic,
            textDecoration = TextDecoration.Underline,
            fontSize=20.sp
        )
        if (p != null) {
            if (edit) {
                TextField(
                    colors = TextFieldDefaults.colors( Color(0xFFC04646), Color.Magenta, cursorColor = Color.Blue),
                    value = p.title,
                    onValueChange = onTitle,
                    label = { Text("ЗАГОЛОВОК") },
                    modifier = Modifier
                        .fillMaxWidth()
                )
                TextField(
                    colors = TextFieldDefaults.colors( Color(0xFFC04646), Color.Magenta, cursorColor = Color.Blue),

                    value = p.body,
                    onValueChange = body,

                    label = { Text("ОПИСАНИЕ") },
                    modifier = Modifier
                        .fillMaxWidth()
                )
                Button(
                    onClick = save,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    shape = CircleShape,
                    border = BorderStroke(5.dp, Color.Black),
                    colors = ButtonDefaults.buttonColors(Color(0xFFEB7D7D)),
                    elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
                    contentPadding = PaddingValues(16.dp)

                ) {
                    Text(stringResource(R.string.save))
                }
            } else {
                Text(
                    text = stringResource(R.string.title),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    fontFamily= FontFamily.Serif,
                    color = Color.Blue,
                    fontStyle = FontStyle.Italic,
                    fontSize=20.sp
                )
                Text(
                    text = p.title,
                    modifier = Modifier.fillMaxWidth(),
                    fontFamily= FontFamily.Serif,
                    color = Color.Blue,
                    fontStyle = FontStyle.Italic,
                    fontSize=17.sp
                )
                Text(
                    text = stringResource(R.string.body),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    fontFamily= FontFamily.Serif,
                    color = Color.Blue,
                    fontStyle = FontStyle.Italic,
                    fontSize=20.sp
                )
                Text(
                    text = p.body,
                    fontFamily= FontFamily.Serif,
                    color = Color.Blue,
                    fontStyle = FontStyle.Italic,
                    fontSize=17.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                )
                Spacer(modifier = Modifier.padding(vertical = 12.dp))
                Button(
                    onClick = onEdit,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    shape = CircleShape,
                    border = BorderStroke(2.dp, Color.Black),
                    colors = ButtonDefaults.buttonColors(Color(0xFFEB7D7D)),
                    elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    Text(stringResource(R.string.edit),fontSize=14.sp,fontFamily= FontFamily.Serif,
                        fontStyle = FontStyle.Italic, color = Color.Black)
                }
            }
        } else {
            Text(
                text = stringResource(R.string.no_post),fontSize=17.sp,
            )
        }
    }
}
