package com.example.net.data

import com.example.net.model.Post
import com.example.net.net.API
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow


class DataRep {

    private val postApi = API.create()

    fun getPosts(): Flow<List<Post>> {
        return flow {
            val posts = postApi.getPosts()
            emit(posts)
        }
    }

    fun updatePost(post: Post): Flow<Post> {
        return flow {
            val updatedPost = postApi.updatePost(post.id, post)
            emit(updatedPost)
        }
    }
}